<div id="notificationArea">
    <?php
    ValidationNotification($errors);
    Notification();
    ?>
</div>