<?php
/**
 * Created by PhpStorm.
 * User: optima
 * Date: 12/13/16
 * Time: 4:23 PM
 */

namespace App\Modules\Collections;


class Collection extends \Eloquent
{
    protected $table = 'collections';

}