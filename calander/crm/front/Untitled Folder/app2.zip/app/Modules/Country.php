<?php
/**
 * Created by PhpStorm.
 * User: optima
 * Date: 10/30/17
 * Time: 12:49 PM
 */

namespace App\Modules;


class Country extends \Eloquent
{
    protected $table = 'countries';

}