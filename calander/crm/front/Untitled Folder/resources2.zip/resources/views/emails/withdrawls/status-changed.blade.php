<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>Withdraw Request {!! \App\Modules\Withdraws\Withdraw::$statusLabel[$withdraw->status]  !!} </h2>

<div>
    <strong>Remarks: </strong> {{ $withdraw->remarks }}

    <br/><br/>
    Moretti Milano
</div>
</body>
</html>