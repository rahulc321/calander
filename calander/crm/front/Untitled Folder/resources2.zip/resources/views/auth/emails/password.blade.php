<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h4>Your Password.</h4>
		<div>
		
		Dear User
			<br/>
			
			Click here to RESET your Password: {{ url('password/reset/'.$token) }}

			<br/><br/>
			Moretti Milano

		</div>
	</body>
</html>
