<?php

class ServicesEntity
{
    public $ID;
    public $Name;
    public $Price;
    public $image;
    public $Description;
    
    function __construct($ID, $Name, $Price, $image, $Description)
    {
        $this->ID = $ID;
        $this->Name = $Name;
        $this->Price = $Price;
        $this->image = $image;
        $this->Description = $Description;
        
    }
    
}


?>