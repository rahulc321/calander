<!doctype html>
<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta name="description" content="This is a Five Family Members Tree Website!">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="keywords" content="Famil, Khouri, Daniel, Tree">
    <meta name="author" content="Daniel Khouri">
	<title>Daniel Khouri Family Tree</title>

<style>
    .blue {
color: blue;
font-size: 35px;
font-family: Helvetica;
}


</style>
</head>

<body>
    
<p>
    
    <a href="/">Home</a>
    <a href="/phpinfo.php">PHPInfo</a>
    <a href="report.php">Hosting Report</a>
    
</p>
    <h1 class="blue">Daniel Khouri Family Tree</h1>
    
<p> <?php

echo "5couldhost is a good solid webhosting. They provide a fast and reliable service, where most of the client’s needs can be easily met with ease of access, and user friendly interface. There service provide a wide range of programing languages helping the user meet their own preference and criteria. In addition, their services are one of the cheapest on the market today.";

?> </p>

<p> <?php

echo "While the above are some of their advantages, however, they don’t own their own servers, which means that they are subject to unforeseen issues. Those issues can consist of possible troubleshooting, or may include business deals that could change at any moment’s notice.";

?> </p>

<p></p>

<?php
// outputs e.g. 'Last modified: March 04 1998 20:43:59.'
echo "Last modified: " . date ("F d Y H:i:s.", getlastmod());
?>

<p></p>

</body>
</html>




