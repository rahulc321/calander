<?php
require ("./Model/ServicesModel.php");


//Contains non-database related function for the Services page.

class ServicesController
{
    function CreateServicesDropdownList()
    {
        $ServicesModel = new ServicesModel();
        $result = "<form action = 'Services.php' method = 'post'>
        Please select a type:
            <select name = 'types' >
            <option value = '%' > All</option>
            ".$this->CreateOptionValues($ServicesModel->GetServicesTypes()).
            "</select>
            <input type = 'submit' value = 'Search' />
            </form>";
            
        return $result;
    }
    
    function CreateOptionValues(array $valueArray)
    {
        $result = "";
        
        foreach ($valueArray as $value)
        {
            $result = $result . "<option value='$value'>$value</option>";
        }
        return $result;
    }
    
    function CreateServicesTables ($types)
    {
        //echo "types, $types\n";
        $ServicesModel = new ServicesModel();
        $ServicesArray = $ServicesModel->GetServicesByType($types);
        $result = "";
        //var_dump($ServicesArray);
        //Generate a ServicesTable for each ServicesEntity in array
        foreach ($ServicesArray as $key => $services)
        {
            //var_dump($services);
            
            $result = $result .
            "<table class = 'servicesTable'>
            <tr>
            <td rowspan='3'><img class='serviceimages' alt='product image' src = '$services->image' /></td>
            <td>Name:</td>
            <td>$services->Name</td>
            </tr>
            
            <tr>
            <td>Price:</td>
            <td>$services->Price</td>
            </tr>
            
            <tr>
            <td>Description:</td>
            <td>$services->Description</td>
            </tr>
            
            </table>";
        }
        return $result;
    }
}


?>