<!doctype html>
<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta name="description" content="This is a Five Family Members Tree Website!">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="keywords" content="Famil, Khouri, Daniel, Tree">
    <meta name="author" content="Daniel Khouri">
	<title>Daniel Khouri Family Tree</title>

<style>
    .blue {
color: blue;
font-size: 35px;
font-family: Helvetica;
}


</style>
</head>

<body>
    
<p>
    
    <a href="/">Home</a>
    <a href="/phpinfo.php">PHPInfo</a>
    <a href="report.php">Hosting Report</a>
    
</p>

    <h1 class="blue">Daniel Khouri Family Tree</h1>
    
    <?php
// outputs e.g. 'Last modified: March 04 1998 20:43:59.'
echo "Last modified: " . date ("F d Y H:i:s.", getlastmod());
?>
    
<?php

echo phpinfo();

?>

<p></p>

<p></p>

</body>
</html>




