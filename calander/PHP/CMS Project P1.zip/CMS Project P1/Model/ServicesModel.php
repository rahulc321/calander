<?php

//echo "servicesModel";

require ("./Entities/ServicesEntity.php");

// Contains database related code for the Computer Services page.
class ServicesModel

{
    //Get all services types from the database and return them in an array.
    function GetServicesTypes()
    {
        require 'Credentials.php';
        
        //Open connection and Select database.
        $link=mysqli_connect ($host,$user,$passwd, $database) or die(mysqli_connect_error());
        //mysql_select_db($database);
        $query = "SELECT DISTINCT Type FROM Services;";
        $result = mysqli_query($link, $query) or die(mysqli_error($link));
        $types = array();
        
        //Get data from database.
        while($row = mysqli_fetch_array($result))
        {
            array_push($types, $row[0]);
        }
        //Close connection and return result.
        mysqli_close();
        return $types;
    }
    //Get ServicesEntity objects from the database and return them in an array.
    function GetServicesByType($type)
    {
        
        require 'Credentials.php';
        
        //Open connection and Select database.
        $link=mysqli_connect($host, $user, $passwd, $database) or die (mysqli_connect_error());
        //mysql_select_db($database);
        
        $query = "SELECT * FROM Services WHERE Type LIKE '$type'";
        //$query = "SELECT * FROM Services;";
       
        $result = mysqli_query($link, $query) or die(mysqli_error($link));
        $servicesArray = array();
        
       // echo $query;
        
        //echo "Services Test";
        
        //Get data from database.
        while($row = mysqli_fetch_array($result))
        {
            $Type = $row[1];
            $Name = $row[2];
            $Price = $row[3];
            $image = $row[4];
            $Description = $row[5];
            
        //echo $Name;
            
            //Create services objects and store them in an array
            $services = new ServicesEntity(-1,$Name,$Price,$image,$Description);
            
            array_push($servicesArray, $services);
        }
        
        //Close connection and return result
            mysqli_close($link);
            //var_dump($servicesArray);
            return $servicesArray;
    }
}

?>