<?php

// login data for the database. use this file in all Models

$host = "localhost";
$user = "danielkh_danielkhouri";
$passwd = "CSIS410Project";
$database = "danielkh_ComputerServicesDB";

?>