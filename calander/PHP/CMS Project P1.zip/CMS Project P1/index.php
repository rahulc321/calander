<?php
$title = "Home";
$content = '<img src="Images/Bible.jfif" class="imagLeft" alt="bible image"/>
<h3>We Believe:</h3>
<p>
   "Whatever you do, work heartily, as for the Lord and not for men, knowing that from the Lord you will receive the inheritance as your reward. You are serving the Lord Christ." (Colossians 3:23-24) 
</p>

<img src="Images/MobileApps.jpg" class="imagRight" alt="mobile image"/>
<h3>Title 2</h3>
<p>
    In order to prevent unauthorized access to the family or friend tree, develop a login page that fronts these pages and requires a session for their viewing. Allow the username “customer” and password “customer” to successfully login to the website. If the username/password is wrong, the instructor may not be able to grade this and you will received a reduction in points. 
Create a proper session for the “customer” username upon authentication. Each page of the family tree should require a session to be set and the user to be authenticated in order to view it. If no session exists, the user should be given a message indicating they are not authenticated and be automatically redirected to the login page. 
Proper form validation should be used and special characters for the password field that disallow bystanders from seeing the password. In addition, if a session exists the footer of each web page should have a logout link. When the logout link is clicked, the user should be asked to confirm or cancel their logout. Once confirmed, the session should be destroyed.
 
</p>

<img src="Images/worldMap.jpg" class="imagLeft" alt="world map"/>
<h3>Title 3</h3>
<p>
    
</p>';

include 'Template.php';
?>
