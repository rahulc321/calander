<?php



require './Controller/ServicesController.php';


$servicesController = new ServicesController ();

if(isset($_POST['types']))
{
    //Fill page with services of the selected type
    $servicesTables = $servicesController->CreateServicesTables($_POST['types']);
}

else
{
    //Page is loaded for the first time, no type selected -> Fetch all types
    $servicesTables = $servicesController->CreateServicesTables('%');
}

//Output page data

//echo "Hi";



$title = 'Services overview';
$content = $servicesController->CreateServicesDropdownList(). $servicesTables;

include 'Template.php';

?>